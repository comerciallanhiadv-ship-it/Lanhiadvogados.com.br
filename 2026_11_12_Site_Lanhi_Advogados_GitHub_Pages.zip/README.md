# Lanhi Advogados — site oficial

Site estático (HTML + imagens) publicado pelo GitHub Pages em https://www.lanhiadvogados.com.br

- `index.html`: página completa (estilos e scripts embutidos)
- `img/`: imagens em AVIF, WebP e JPG
- `CNAME`: domínio personalizado usado pelo GitHub Pages
- `404.html`: leva endereços antigos para a página inicial

Para alterar o site, edite os arquivos e faça commit na branch `main`; o GitHub Pages publica sozinho em cerca de um minuto.
